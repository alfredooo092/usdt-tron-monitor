# Deploy no Render - USDT Tron Monitor

## 🚀 Passos para Deploy no Render

### 1. Preparar Repositório Git

```bash
# Extrair o ZIP
unzip usdt-tron-monitor.zip
cd usdt-tron-final

# Inicializar Git
git init
git add .
git commit -m "Initial commit - USDT Tron Monitor"

# Conectar ao GitHub (opcional)
# git remote add origin https://github.com/seu-usuario/usdt-tron-monitor.git
# git push -u origin main
```

### 2. Configurar no Render

1. **Acesse:** https://render.com
2. **Faça login** ou crie conta gratuita
3. **Clique:** "New +" → "Web Service"
4. **Conecte repositório** ou faça upload do código

### 3. Configurações do Deploy

**Build & Deploy:**
- **Environment:** Python 3
- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `python src/main.py`
- **Instance Type:** Free (suficiente para testes)

**Environment Variables:**
- `PYTHON_VERSION`: 3.11.0
- `FLASK_ENV`: production

### 4. Configurações Avançadas

**Auto-Deploy:** Ativado (recomendado)
**Health Check Path:** `/` (opcional)

### 5. Após Deploy

- Render fornecerá uma URL como: `https://seu-app.onrender.com`
- Acesse com as credenciais:
  - **Usuário:** admin
  - **Senha:** 123456

## 🔧 Arquivos de Configuração Incluídos

- ✅ `render.yaml` - Configuração automática do Render
- ✅ `runtime.txt` - Versão do Python
- ✅ `requirements.txt` - Dependências Python
- ✅ `src/main.py` - Configurado para produção

## 📊 Funcionalidades Confirmadas

- ✅ **APIs reais** da blockchain Tron
- ✅ **Saldos atualizados** em tempo real
- ✅ **Transações verificáveis** no TronScan
- ✅ **Interface responsiva** para mobile/desktop
- ✅ **Persistência** de dados no navegador

## 🆘 Troubleshooting

**Se der erro no deploy:**
1. Verifique se todos os arquivos foram enviados
2. Confirme que `requirements.txt` está presente
3. Verifique logs no painel do Render
4. Teste localmente primeiro

**Logs importantes:**
- Build logs mostram instalação de dependências
- Deploy logs mostram inicialização da aplicação
- Runtime logs mostram erros em produção

## 💡 Dicas

- **Deploy gratuito** no Render tem algumas limitações
- **Aplicação hiberna** após 15min sem uso (plano gratuito)
- **Primeira requisição** pode ser mais lenta (cold start)
- **URLs são permanentes** uma vez criadas

---
**Pronto para produção!** 🚀

